# Millennial Media iOS Advertising SDK 6.0.0

## Requirements

* iOS 7.0+
* Xcode 6.4+

## Integration

Refer to [Millennial Media Developer Documentation](http://docs.millennialmedia.com/) for the latest integration instructions.