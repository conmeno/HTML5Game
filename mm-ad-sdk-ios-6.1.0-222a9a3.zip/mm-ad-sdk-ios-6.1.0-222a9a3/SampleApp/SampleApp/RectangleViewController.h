//
//  InlineViewController.h
//  SampleApp
//
//  Copyright (c) 2015 Millennial Media. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MMAdSDK/MMAdSDK.h>

@interface RectangleViewController : UIViewController <MMInlineDelegate>

@property (nonatomic, weak) IBOutlet UIView *adContainer;
@property (nonatomic, strong) MMInlineAd *rectangleAd;

@end
