//
//  BannerViewController.m
//  SampleApp
//
//  Copyright (c) 2015 Millennial Media. All rights reserved.
//

#import "BannerViewController.h"

NSString *const kSampleAppBannerAdPlacementID = @"203888";

@implementation BannerViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"Banner";
    self.automaticallyAdjustsScrollViewInsets = NO;

    MMInlineAdSize adSize = (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone) ? MMInlineAdSizeBanner :MMInlineAdSizeLeaderboard;
    self.inlineAd = [[MMInlineAd alloc] initWithPlacementId:kSampleAppBannerAdPlacementID adSize:adSize];
    self.inlineAd.delegate = self;
    self.inlineAd.refreshInterval = 60;
    [self.adContainer addSubview:self.inlineAd.view];
    [self centerAdInContainer];
    [self.inlineAd request:nil];
}

- (IBAction)requestInline:(id)sender {
    [self.inlineAd request:nil];
}

#pragma mark - Inline Delegate

- (void)inlineAdRequestDidSucceed:(MMInlineAd *)ad {
    NSLog(@"Inline request succeeded.");
}

- (void)inlineAd:(MMInlineAd *)ad requestDidFailWithError:(NSError *)error {
    NSLog(@"Inline ad failed: %@.", error);
}

- (void)inlineAdContentTapped:(MMInlineAd *)ad {
    NSLog(@"Inline ad tapped.");
}

- (void)inlineAd:(MMInlineAd *)ad willResizeTo:(CGRect)frame isClosing:(BOOL)isClosingResize {
    NSLog(@"Inline ad is %@ and will resize to frame %@.", isClosingResize ? @"closing" : @"resizing", NSStringFromCGRect(frame));
}

- (void)inlineAd:(MMInlineAd *)ad didResizeTo:(CGRect)frame isClosing:(BOOL)isClosingResize {
    NSLog(@"Inline ad is %@ and did resize to frame %@.", isClosingResize ? @"closing" : @"resizing", NSStringFromCGRect(frame));
}

- (void)inlineAdWillPresentModal:(MMInlineAd *)ad {
    NSLog(@"Inline ad will present modal view.");
}

- (void)inlineAdDidPresentModal:(MMInlineAd *)ad {
    NSLog(@"Inline ad did present modal view.");
}

- (void)inlineAdWillCloseModal:(MMInlineAd *)ad {
    NSLog(@"Inline ad will close modal view.");
}

- (void)inlineAdDidCloseModal:(MMInlineAd *)ad {
    NSLog(@"Inline ad did close modal view.");
}

- (void)inlineAdWillLeaveApplication:(MMInlineAd *)ad {
    NSLog(@"Inline ad will leave application.");
}

- (UIViewController *)viewControllerForPresentingModalView {
    return self;
}

#pragma mark - Autolayout

- (void)centerAdInContainer {
    NSLayoutConstraint *centerX = [NSLayoutConstraint constraintWithItem:self.inlineAd.view attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:self.adContainer attribute:NSLayoutAttributeCenterX multiplier:1.0 constant:0];
    [self.view addConstraint:centerX];
}

@end
