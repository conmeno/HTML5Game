//
//  AppDelegate.h
//  SampleApp
//
//  Copyright (c) 2015 Millennial Media. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

