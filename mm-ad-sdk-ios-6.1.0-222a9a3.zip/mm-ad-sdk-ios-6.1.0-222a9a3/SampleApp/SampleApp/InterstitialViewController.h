//
//  InterstitialViewController.h
//  SampleApp
//
//  Copyright (c) 2015 Millennial Media. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MMAdSDK/MMAdSDK.h>

@interface InterstitialViewController : UIViewController <MMInterstitialDelegate>

@property (nonatomic, strong) MMInterstitialAd *interstitialAd;

@end
