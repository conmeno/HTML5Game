//
//  NativeViewController.m
//  SampleApp
//
//  Copyright (c) 2015 Millennial Media. All rights reserved.
//

#import "NativeViewController.h"

static NSString *const kSampleAppNativeAdPlacementID = @"203891";
static NSString *const kTallLayoutName = @"TallLayout";
static NSString *const kShortLayoutName = @"ShortLayout";

static const CGFloat kFadeInOutDuration = 0.3;
static const CGFloat kTallLayoutHeight = 305.0;
static const CGFloat kStandardUIComponentSpace = 20.0;

@interface NativeViewController()
@property (nonatomic, weak) UIView *nativeAdContainer;
@property (nonatomic, weak) IBOutlet UIButton *requestButton;
@property (nonatomic, weak) IBOutlet UIButton *showButton;
@property (nonatomic, assign) BOOL firstRequest;
@end

@implementation NativeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"Native";
    
    self.showButton.enabled = NO;
    [self requestAd:self];
    self.firstRequest = YES;
}

#pragma mark - Layout

- (void)removeNativeAdContainer {
    [self.nativeAdContainer removeFromSuperview];
    self.nativeAdContainer = nil;
}

- (void)setupNativeContainer:(CGSize)size {
    [self removeNativeAdContainer];
    
    NSString *layoutBundleName;
    if ([self availableHeightForSize:size] >= kTallLayoutHeight) {
        layoutBundleName = kTallLayoutName;
    }
    else {
        layoutBundleName = kShortLayoutName;
    }
    
    NSURL *layoutBundleURL = [[NSBundle mainBundle] URLForResource:layoutBundleName withExtension:@"bundle"];
    NSBundle *layoutBundle = [NSBundle bundleWithURL:layoutBundleURL];
    self.nativeAdContainer = [self.nativeInlineAd loadIntoLayoutFromBundle:layoutBundle];
    self.nativeAdContainer.center = self.view.center;
    [self.view addSubview:self.nativeAdContainer];
}

#pragma mark - User Interaction

- (IBAction)requestAd:(id)sender {
    self.requestButton.enabled = NO;
    
    __weak NativeViewController *weakSelf = self;
    [UIView animateWithDuration:kFadeInOutDuration animations:^{
        weakSelf.nativeAdContainer.alpha = 0.0;
    } completion:^(BOOL finished) {
        [weakSelf removeNativeAdContainer];
    }];
    
    self.nativeInlineAd = [[MMNativeAd alloc] initWithPlacementId:kSampleAppNativeAdPlacementID supportedTypes:@[MMNativeAdTypeInline]];
    self.nativeInlineAd.delegate = self;
    [self.nativeInlineAd load:nil];
}

- (IBAction)showAd:(id)sender {
    self.showButton.enabled = NO;
    
    [self setupNativeContainer:self.view.bounds.size];
    
    __weak NativeViewController *weakSelf = self;
    [UIView animateWithDuration:kFadeInOutDuration animations:^{
        weakSelf.nativeAdContainer.alpha = 1.0;
        weakSelf.requestButton.enabled = YES;
    }];
}

- (IBAction)adTapped:(id)sender {
    [self.nativeInlineAd invokeDefaultAction];
}

#pragma mark - Helpers

- (CGFloat)availableHeightForSize:(CGSize)size {
    CGFloat availableHeight = size.height;
    availableHeight -= (size.height - self.requestButton.frame.origin.y);  // space for the buttons
    availableHeight -= self.navigationController.navigationBar.frame.size.height;           // space for the nav bar
    availableHeight -= (2 * kStandardUIComponentSpace);                                     // standard UI margins
    return availableHeight;
}

#pragma mark - Rotation

- (void)viewDidTransitionToSize:(CGSize)size withTransitionCoordinator:(id<UIViewControllerTransitionCoordinator>)coordinator {
    // Support for rotation in iOS 8.
    if (self.nativeAdContainer) {
        [self setupNativeContainer:size];
    }
}

- (void)didRotateFromInterfaceOrientation:(UIInterfaceOrientation)fromInterfaceOrientation {
    // Support for rotation in iOS 7.
    if (self.nativeAdContainer) {
        [self setupNativeContainer:self.view.bounds.size];
    }
}

#pragma mark - Native ad delegate methods

- (UIViewController *)viewControllerForPresentingModalView {
    return self;
}

- (void)nativeAdRequestDidSucceed:(MMNativeAd *)nativeAd {
    if (self.firstRequest) {
        [self showAd:self];
        self.firstRequest = NO;
    }
    else {
        self.showButton.enabled = YES;
    }
}

- (void)nativeAd:(MMNativeAd *)ad requestDidFailWithError:(NSError *)error {
    NSLog(@"Native ad request failed: %@.", error);
    if (self.firstRequest) {
        self.firstRequest = NO;
    }
    self.requestButton.enabled = YES;
}

- (void)nativeAdTapped:(MMNativeAd *)ad {
    NSLog(@"Native ad %@ was tapped.", ad);
}

- (void)nativeAdWillLeaveApplication:(MMNativeAd *)ad {
    NSLog(@"Native ad %@ will exit the app.", ad);
}

@end
