//
//  InterstitialViewController.m
//  SampleApp
//
//  Copyright (c) 2015 Millennial Media. All rights reserved.
//

#import "InterstitialViewController.h"

NSString *const kSampleAppInterstitialAdPlacementID = @"203890";

@interface InterstitialViewController ()
@property (nonatomic, weak) IBOutlet UIButton *requestButton;
@property (nonatomic, weak) IBOutlet UIButton *showButton;
@property (nonatomic, assign) BOOL interstitialDisplayed;
@property (nonatomic, assign) BOOL firstRequest;
@end

@implementation InterstitialViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"Interstitial";
    [self updateButtons];
    
    self.interstitialAd = [[MMInterstitialAd alloc] initWithPlacementId:kSampleAppInterstitialAdPlacementID];
    self.interstitialAd.delegate = self;
    self.interstitialAd.modalTransitionStyle = UIModalTransitionStyleCoverVertical;
    [self.interstitialAd load:nil];
    self.firstRequest = YES;
}

- (IBAction)loadInterstitial:(id)sender {
    [self.interstitialAd load:nil];
    [self updateButtons];
}

- (IBAction)displayInterstitial:(id)sender {
    [self.interstitialAd showFromViewController:self];
}

#pragma mark - Button State

- (void)updateButtons {
    if (self.interstitialAd.ready) {
        // New ad is available to show.
        self.requestButton.enabled = NO;
        self.showButton.enabled = YES;
    }
    else if (!self.interstitialDisplayed) {
        // Neither ready nor displayed. Request can be made.
        self.requestButton.enabled = YES;
        self.showButton.enabled = NO;
    }
    else {
        // Request in progress.
        self.requestButton.enabled = NO;
        self.showButton.enabled = NO;
    }
}

#pragma mark - Interstitial Delegate

- (void)interstitialAdLoadDidSucceed:(MMInterstitialAd *)ad {
    [self updateButtons];
    
    if (self.firstRequest) {
        [self.interstitialAd showFromViewController:self];
        self.firstRequest = NO;
    }
}

- (void)interstitialAd:(MMInterstitialAd *)ad loadDidFailWithError:(NSError *)error {
    NSLog(@"Interstitial load failed: %@.", error);
    [self updateButtons];
    self.firstRequest = NO;
}

- (void)interstitialAdWillDisplay:(MMInterstitialAd *)ad {
    NSLog(@"Interstitial will display.");
}

- (void)interstitialAdDidDisplay:(MMInterstitialAd *)ad {
    NSLog(@"Interstitial did display.");
    self.interstitialDisplayed = YES;
}

- (void)interstitialAdWillDismiss:(MMInterstitialAd *)ad {
    NSLog(@"Interstitial will dismiss.");
}

- (void)interstitialAdDidDismiss:(MMInterstitialAd *)ad {
    NSLog(@"Interstitial did dismiss.");
    self.interstitialDisplayed = NO;
    [self updateButtons];
}

- (void)interstitialAdTapped:(MMInterstitialAd *)ad {
    NSLog(@"Interstitial tapped.");
}

- (void)interstitialAdWillLeaveApplication:(MMInterstitialAd *)ad {
    NSLog(@"Interstitial ad will leave application.");
}

@end
