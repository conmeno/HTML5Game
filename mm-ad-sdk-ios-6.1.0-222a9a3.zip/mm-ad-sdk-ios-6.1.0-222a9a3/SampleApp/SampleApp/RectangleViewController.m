//
//  InlineViewController.m
//  SampleApp
//
//  Copyright (c) 2015 Millennial Media. All rights reserved.
//

#import "RectangleViewController.h"

NSString *const kSampleAppRectangleAdPlacementID = @"203889";

@implementation RectangleViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"Rectangle";
    self.automaticallyAdjustsScrollViewInsets = NO;

    self.rectangleAd = [[MMInlineAd alloc] initWithPlacementId:kSampleAppRectangleAdPlacementID adSize:MMInlineAdSizeMediumRectangle];
    self.rectangleAd.delegate = self;
    self.rectangleAd.refreshInterval = 60;
    [self.adContainer addSubview:self.rectangleAd.view];
    [self.rectangleAd request:nil];
}

- (IBAction)requestInline:(id)sender {
    [self.rectangleAd request:nil];
}

#pragma mark - Inline Delegate

- (void)inlineAdRequestDidSucceed:(MMInlineAd *)ad {
    NSLog(@"Inline request succeeded.");
}

- (void)inlineAd:(MMInlineAd *)ad requestDidFailWithError:(NSError *)error {
    NSLog(@"Inline ad failed: %@.", error);
}

- (void)inlineAdContentTapped:(MMInlineAd *)ad {
    NSLog(@"Inline ad tapped.");
}

- (void)inlineAd:(MMInlineAd *)ad willResizeTo:(CGRect)frame isClosing:(BOOL)isClosingResize {
    NSLog(@"Inline ad is %@ and will resize to frame %@.", isClosingResize ? @"closing" : @"resizing", NSStringFromCGRect(frame));
}

- (void)inlineAd:(MMInlineAd *)ad didResizeTo:(CGRect)frame isClosing:(BOOL)isClosingResize {
    NSLog(@"Inline ad is %@ and did resize to frame %@.", isClosingResize ? @"closing" : @"resizing", NSStringFromCGRect(frame));
}

- (void)inlineAdWillPresentModal:(MMInlineAd *)ad {
    NSLog(@"Inline ad will present modal view.");
}

- (void)inlineAdDidPresentModal:(MMInlineAd *)ad {
    NSLog(@"Inline ad did present modal view.");
}

- (void)inlineAdWillCloseModal:(MMInlineAd *)ad {
    NSLog(@"Inline ad will close modal view.");
}

- (void)inlineAdDidCloseModal:(MMInlineAd *)ad {
    NSLog(@"Inline ad did close modal view.");
}

- (void)inlineAdWillLeaveApplication:(MMInlineAd *)ad {
    NSLog(@"Inline ad will leave application.");
}

- (UIViewController *)viewControllerForPresentingModalView {
    return self;
}

@end
